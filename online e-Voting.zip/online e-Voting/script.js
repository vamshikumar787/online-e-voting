// Select Election Type
function selectElectionType(type) {
    sessionStorage.setItem("electionType", type);
    document.querySelectorAll('.election-option').forEach(el => el.classList.remove('selected'));
    document.querySelector(`.election-option[onclick="selectElectionType('${type}')"]`).classList.add('selected');
}

// Go to Candidate Selection Page
function goToCandidates() {
    const electionType = sessionStorage.getItem("electionType");
    if (!electionType) {
        alert("Please select an election type.");
        return;
    }
    window.location.href = "candidates.html";
}

// Load Candidates Dynamically
function loadCandidates() {
    const candidateList = document.getElementById('candidate-list');
    if (candidateList) {
        const electionType = sessionStorage.getItem("electionType");
        const candidates = electionType === "central" 
            ? [{ name: "Candidate A", img: "candidateA.jpg" }, { name: "Candidate B", img: "candidateB.jpg" }]
            : [{ name: "Candidate C", img: "candidateC.jpg" }, { name: "Candidate D", img: "candidateD.jpg" }];

        candidates.forEach(candidate => {
            const div = document.createElement('div');
            div.className = "candidate";
            div.innerHTML = `<img src="${candidate.img}" alt="${candidate.name}"> ${candidate.name}`;
            div.onclick = function () {
                sessionStorage.setItem("selectedCandidate", candidate.name);
                document.querySelectorAll('.candidate').forEach(c => c.classList.remove('selected'));
                div.classList.add('selected');
            };
            candidateList.appendChild(div);
        });
    }
}

// Confirm Vote
function confirmVote() {
    const selectedCandidate = sessionStorage.getItem("selectedCandidate");
    if (!selectedCandidate) {
        alert("Please select a candidate.");
        return;
    }
    sessionStorage.setItem("confirmedCandidate", selectedCandidate);
    window.location.href = "confirmation.html";
}

// Load Confirmation Page
function loadConfirmation() {
    const confirmationText = document.getElementById('selected-candidate-info');
    if (confirmationText) {
        const confirmedCandidate = sessionStorage.getItem("confirmedCandidate");
        confirmationText.textContent = confirmedCandidate 
            ? `You have voted for ${confirmedCandidate}` 
            : "No candidate selected.";
    }
}

// Final Vote Submission
function goToMainPage() {
    alert("Your vote has been successfully submitted!");
    setTimeout(() => {
        window.location.href = "main.html";
    }, 3000);
}

// Back Navigation
function goBack(page) {
    window.location.href = page;
}

// Run Functions on Page Load
window.onload = function () {
    loadCandidates();
    loadConfirmation();
};
